<footer class="bg-dark">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    
    <div class="container py-5 text-light ">

        <div class="row">
            <div class="col-12 col-sm-4" style="text-align: center">All rights reserved Só Jogos! - 2019</div>

            <div class="col-12 col-sm-4" style="text-align: center">@Faculdade de Tecnologia de São Roque</div>

            <div class="col-12 col-sm-4" style="text-align: center">
                <i class="fab fa-facebook"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-whatsapp"></i>
            </div>

        </div>

        <div class="row mt-3">

        </div>

    </div>

</footer>

<script src="js/jquery-3.3.1.min.js"></script>

<!-- Sub Menu "Categorias" -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/scripts.js"></script>

</body>

</html>
