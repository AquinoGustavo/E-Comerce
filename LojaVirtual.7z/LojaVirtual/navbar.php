

<nav class="navbar navbar-dark bg-secondary navint px-5 py-2">
        <div class="container">
            <button class="navbar-toggler bg-secondary" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="index.php"><img src="img/logotipo"></a>
            <form class="form-inline" action="/action_page.php">
                <input class="form-control mr-sm-3" type="text" placeholder="Search">
                <button class="btn btn-success" type="submit">Search</button>
            </form>
            <div class="">
                <i class="fab fa-facebook"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-whatsapp"></i>
            </div>
        </div>
    </nav>

<div class="pos-f-t d-none d-sm-block">
    <div class="collapse" id="navbarToggleExternalContent">
        <ul class="navbar-nav ml-auto px-5 py-3 bg-dark navi">
            <!-- <li class="nav-item dropdown">
                <a href="" class="nav-link dropdown-toggle text-white" data-toggle="dropdown" id="navbarDropdownMenuLink">Categorias</a>
                <div class="dropdown-menu">
                    <a href="..." class="dropdown-item">Celulares e Comunicação</a>
                    <a href="..." class="dropdown-item">Eletrônicos, TV e Audio</a>
                    <a href="..." class="dropdown-item">Computadores e Informática</a>
                    <a href="..." class="dropdown-item">Cd, Dvd e Blu-ray</a>
                    <a href="..." class="dropdown-item">Kindle, eBooks e Livros</a>
                </div>
            </li> -->
            <!-- <li class="nav-item">
                <a href="..." class="nav-link text-white">Iniciar</a>
            </li> -->
            <li class="nav-item">
                <a href="index_login.php" class="nav-link text-white">Login</a>
            </li>
            <!-- <li class="nav-item">
                <a href="..." class="nav-link text-white">Carrinho</a>
            </li> -->
        </ul>
    </div>
</div>

